var searchData=
[
  ['finalitzar_5ftorneig_26',['finalitzar_torneig',['../class_cjt__tornejos.html#aab5eafe1fe6bb194a3a3350723b9c734',1,'Cjt_tornejos::finalitzar_torneig()'],['../class_torneig.html#a6437f391b759b9488c2683462fb49899',1,'Torneig::finalitzar_torneig()']]]
];
