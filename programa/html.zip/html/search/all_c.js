var searchData=
[
  ['ranking_68',['ranking',['../class_cjt__jugadors.html#af9f7e71820fb657bf489ce72a31e8034',1,'Cjt_jugadors']]],
  ['restar_5fpunts_69',['restar_punts',['../class_torneig.html#ac8a8318fd1bc940649d12e300906c530',1,'Torneig']]]
];
