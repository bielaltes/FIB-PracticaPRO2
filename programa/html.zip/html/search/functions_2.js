var searchData=
[
  ['calcular_5fguanyadors_98',['calcular_guanyadors',['../class_torneig.html#a0ce999e54df0dca139778eb49954d09e',1,'Torneig']]],
  ['cjt_5fcategories_99',['Cjt_categories',['../class_cjt__categories.html#a0a7b9eae526afdb8c18269fefcee1174',1,'Cjt_categories']]],
  ['cjt_5fjugadors_100',['Cjt_jugadors',['../class_cjt__jugadors.html#a473281833edd8838e3517fff07a6b9f1',1,'Cjt_jugadors']]],
  ['cjt_5ftornejos_101',['Cjt_tornejos',['../class_cjt__tornejos.html#a802f937a72b37c2a675734cb3d6f6257',1,'Cjt_tornejos']]],
  ['cmp_102',['cmp',['../_cjt__jugadors_8cc.html#a8e1554988fecbc208b3b14d3ad09f003',1,'Cjt_jugadors.cc']]],
  ['consultar_5fcategoria_103',['consultar_categoria',['../class_torneig.html#a78a82b011e01b5d07ade6378da916c3c',1,'Torneig']]],
  ['consultar_5fjugador_104',['consultar_jugador',['../class_cjt__jugadors.html#a7f4014b50e2bf91f3b5e7286c2385edc',1,'Cjt_jugadors']]],
  ['consultar_5fposicio_105',['consultar_posicio',['../class_jugador.html#ac23e47ec747a3bfcabcf047ef9b599de',1,'Jugador']]],
  ['consultar_5fpunts_106',['consultar_punts',['../class_cjt__categories.html#a21bb1f3a366e5e5a59130dc9d65b799c',1,'Cjt_categories']]],
  ['crear_5femparellaments_107',['crear_emparellaments',['../class_torneig.html#ae6722ca037250a8904e52322332fa461',1,'Torneig']]]
];
