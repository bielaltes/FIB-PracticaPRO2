var searchData=
[
  ['eliminar_5fjugador_23',['eliminar_jugador',['../class_cjt__tornejos.html#acd74b9196cc0c9af8cc572e2112d0279',1,'Cjt_tornejos']]],
  ['eliminar_5fparticipant_24',['eliminar_participant',['../class_torneig.html#abb513cd4c98a86b799736b8118f94c5b',1,'Torneig']]],
  ['escriure_5fjugador_25',['escriure_jugador',['../class_jugador.html#a2649293855d738934650cd8e26011df2',1,'Jugador']]]
];
