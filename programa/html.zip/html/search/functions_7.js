var searchData=
[
  ['llegir_5fcategories_121',['llegir_categories',['../class_cjt__categories.html#aec7c99f38b0e4a59e804b5bf9ed1a4c8',1,'Cjt_categories']]],
  ['llegir_5finscripcio_122',['llegir_inscripcio',['../class_torneig.html#ac0ec8f0a5c71dd78980c86f3ccc75620',1,'Torneig']]],
  ['llegir_5fjugadors_123',['llegir_jugadors',['../class_cjt__jugadors.html#affe03f05c962b8689540de5e1aa97d0a',1,'Cjt_jugadors']]],
  ['llegir_5fresultats_124',['llegir_resultats',['../class_torneig.html#a426f250284ac487531cc5247a2b35154',1,'Torneig']]],
  ['llegir_5ftornejos_125',['llegir_tornejos',['../class_cjt__tornejos.html#a1353b909daa12fb1f542d028f1d79529',1,'Cjt_tornejos']]]
];
