var searchData=
[
  ['torneig_82',['Torneig',['../class_torneig.html',1,'']]]
];
