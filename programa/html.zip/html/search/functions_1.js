var searchData=
[
  ['baixa_5fjugador_96',['baixa_jugador',['../class_cjt__jugadors.html#a45f7ccbdbfe93b545fa82a846f1e767d',1,'Cjt_jugadors']]],
  ['baixa_5ftorneig_97',['baixa_torneig',['../class_cjt__tornejos.html#a77750c86e1c2b57d8781e565bbd22625',1,'Cjt_tornejos']]]
];
