var searchData=
[
  ['restar_5fpunts_134',['restar_punts',['../class_torneig.html#ac8a8318fd1bc940649d12e300906c530',1,'Torneig']]]
];
