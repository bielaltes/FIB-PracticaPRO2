var searchData=
[
  ['nom_145',['nom',['../class_jugador.html#afd6bec98df8ebb3d2db3ef583a76cfa1',1,'Jugador']]],
  ['noms_146',['noms',['../class_cjt__categories.html#a45622c30fae365dc72f2d7aa5fbc3bfc',1,'Cjt_categories']]],
  ['num_5fparticipants_147',['num_participants',['../class_torneig.html#aef9f0b6e93895593e4527cdd3e4e31ea',1,'Torneig']]],
  ['num_5ftornejos_148',['num_tornejos',['../class_cjt__tornejos.html#afe968dc02bf4f83842c53c5a76182f2f',1,'Cjt_tornejos']]]
];
