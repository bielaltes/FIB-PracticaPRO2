var searchData=
[
  ['anteriors_5fparticipants_137',['anteriors_participants',['../class_torneig.html#a5ce5110cbb6fc8a30ec94bdeb5c837cb',1,'Torneig']]]
];
