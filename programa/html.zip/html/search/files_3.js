var searchData=
[
  ['torneig_2ecc_92',['Torneig.cc',['../_torneig_8cc.html',1,'']]],
  ['torneig_2ehh_93',['Torneig.hh',['../_torneig_8hh.html',1,'']]]
];
