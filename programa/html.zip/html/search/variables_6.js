var searchData=
[
  ['ranking_156',['ranking',['../class_cjt__jugadors.html#af9f7e71820fb657bf489ce72a31e8034',1,'Cjt_jugadors']]]
];
