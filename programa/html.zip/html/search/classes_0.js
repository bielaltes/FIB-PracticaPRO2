var searchData=
[
  ['cjt_5fcategories_78',['Cjt_categories',['../class_cjt__categories.html',1,'']]],
  ['cjt_5fjugadors_79',['Cjt_jugadors',['../class_cjt__jugadors.html',1,'']]],
  ['cjt_5ftornejos_80',['Cjt_tornejos',['../class_cjt__tornejos.html',1,'']]]
];
