var searchData=
[
  ['sumar_5fposicio_135',['sumar_posicio',['../class_jugador.html#acf0b8889293fdbe6e94edb4537847350',1,'Jugador']]]
];
