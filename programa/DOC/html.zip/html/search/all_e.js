var searchData=
[
  ['sets_5fguanyat_88',['sets_guanyat',['../class_jugador.html#a396b226c722425d387f36e239fc9855c',1,'Jugador']]],
  ['sets_5fperdut_89',['sets_perdut',['../class_jugador.html#a7c9fcb3ec52c2c400e7cf8faaf945426',1,'Jugador']]],
  ['sumar_5fposicio_90',['sumar_posicio',['../class_jugador.html#acf0b8889293fdbe6e94edb4537847350',1,'Jugador']]]
];
