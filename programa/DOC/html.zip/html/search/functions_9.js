var searchData=
[
  ['node_162',['Node',['../struct_bin_tree_1_1_node.html#af45885e303875c018e89fa5c8b96bde0',1,'BinTree::Node']]],
  ['nom_5fcategoria_163',['nom_categoria',['../class_cjt__categories.html#abf84a9eb9c89846b4746a8f0cc3afb2f',1,'Cjt_categories']]],
  ['nom_5fjugador_164',['nom_jugador',['../class_cjt__jugadors.html#afb644fcd07419fb30dc37db5a1663a73',1,'Cjt_jugadors']]],
  ['nou_5fjugador_165',['nou_jugador',['../class_cjt__jugadors.html#ad59d2f11a4bbfd1053c0dba9062595af',1,'Cjt_jugadors']]],
  ['nou_5ftorneig_166',['nou_torneig',['../class_cjt__tornejos.html#a71e258c45895e7e97bdf201bec99f865',1,'Cjt_tornejos']]],
  ['num_5fcategories_167',['num_categories',['../class_cjt__categories.html#a78445bc84e521a95e7314ec4ac2565ad',1,'Cjt_categories']]]
];
