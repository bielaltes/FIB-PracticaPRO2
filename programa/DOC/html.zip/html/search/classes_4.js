var searchData=
[
  ['torneig_110',['Torneig',['../class_torneig.html',1,'']]]
];
