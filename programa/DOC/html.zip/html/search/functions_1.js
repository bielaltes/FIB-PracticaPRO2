var searchData=
[
  ['baixa_5fjugador_126',['baixa_jugador',['../class_cjt__jugadors.html#a45f7ccbdbfe93b545fa82a846f1e767d',1,'Cjt_jugadors']]],
  ['baixa_5ftorneig_127',['baixa_torneig',['../class_cjt__tornejos.html#a77750c86e1c2b57d8781e565bbd22625',1,'Cjt_tornejos']]],
  ['bintree_128',['BinTree',['../class_bin_tree.html#a1408d37d1afda12d99747d09543c15f4',1,'BinTree::BinTree(shared_ptr&lt; Node &gt; p)'],['../class_bin_tree.html#a47eef22d29cd023449d97c073c08e5b6',1,'BinTree::BinTree()'],['../class_bin_tree.html#a1ab686e0bcf990093ff91fe71744c1a4',1,'BinTree::BinTree(const T &amp;x)'],['../class_bin_tree.html#adb7eeff76d08130c943b36af215eb521',1,'BinTree::BinTree(const T &amp;x, const BinTree &amp;left, const BinTree &amp;right)']]]
];
