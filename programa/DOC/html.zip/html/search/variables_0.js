var searchData=
[
  ['alcaraz_178',['Alcaraz',['../proves_8cc.html#aea2878a909755316e0279cb8d6d34d4d',1,'proves.cc']]],
  ['anteriors_5fparticipants_179',['anteriors_participants',['../class_torneig.html#a5ce5110cbb6fc8a30ec94bdeb5c837cb',1,'Torneig']]]
];
