var searchData=
[
  ['tornejos_212',['tornejos',['../class_cjt__tornejos.html#a4b3d9bdd2ed133d76284fb510ebe9800',1,'Cjt_tornejos']]],
  ['tornejos_5fdisputat_213',['tornejos_disputat',['../class_jugador.html#a2ef0821abd64385a58561b039c37a469',1,'Jugador']]]
];
