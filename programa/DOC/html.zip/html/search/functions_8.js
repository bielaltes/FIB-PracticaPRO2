var searchData=
[
  ['main_159',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;program.cc'],['../proves_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;proves.cc']]],
  ['modificar_5festadistiques_160',['modificar_estadistiques',['../class_jugador.html#ab002dbf870a93bbe498d1f76f9e43e43',1,'Jugador']]],
  ['modificar_5fposicio_161',['modificar_posicio',['../class_jugador.html#aa9e09965d8b76997ec4913ca355daf1e',1,'Jugador']]]
];
