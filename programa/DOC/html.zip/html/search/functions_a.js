var searchData=
[
  ['restar_5fpunts_168',['restar_punts',['../class_torneig.html#ac8a8318fd1bc940649d12e300906c530',1,'Torneig']]],
  ['right_169',['right',['../class_bin_tree.html#aff8e96651b27284c329667b5ad3e4d0b',1,'BinTree']]]
];
