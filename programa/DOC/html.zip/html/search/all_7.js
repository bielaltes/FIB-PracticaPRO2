var searchData=
[
  ['jocs_5fguanyat_45',['jocs_guanyat',['../class_jugador.html#a0eb97835e7dd3143f626c1d15edb7392',1,'Jugador']]],
  ['jocs_5fperdut_46',['jocs_perdut',['../class_jugador.html#a04e5cf90e57c490b4c088e29763479f7',1,'Jugador']]],
  ['jugador_47',['Jugador',['../class_jugador.html',1,'Jugador'],['../class_jugador.html#a0bac6ebd78bbdc5ed61be887a163ecc0',1,'Jugador::Jugador()']]],
  ['jugador_2ecc_48',['Jugador.cc',['../_jugador_8cc.html',1,'']]],
  ['jugador_2ehh_49',['Jugador.hh',['../_jugador_8hh.html',1,'']]],
  ['jugadors_50',['jugadors',['../class_cjt__jugadors.html#a9a7fd899cca7f3c126120c8e7b4719d4',1,'Cjt_jugadors']]],
  ['jugat_51',['jugat',['../class_torneig.html#a01d94829488fe4daba0cba870f2bcccf',1,'Torneig']]]
];
