var searchData=
[
  ['left_54',['left',['../struct_bin_tree_1_1_node.html#a265a6367635a38838e6a6366564be78d',1,'BinTree::Node::left()'],['../class_bin_tree.html#a82108db4c1b08d1f111027788c196d4e',1,'BinTree::left()']]],
  ['llegir_5fcategories_55',['llegir_categories',['../class_cjt__categories.html#aec7c99f38b0e4a59e804b5bf9ed1a4c8',1,'Cjt_categories']]],
  ['llegir_5finscripcio_56',['llegir_inscripcio',['../class_torneig.html#ac0ec8f0a5c71dd78980c86f3ccc75620',1,'Torneig']]],
  ['llegir_5fjugadors_57',['llegir_jugadors',['../class_cjt__jugadors.html#affe03f05c962b8689540de5e1aa97d0a',1,'Cjt_jugadors']]],
  ['llegir_5fresultats_58',['llegir_resultats',['../class_torneig.html#a426f250284ac487531cc5247a2b35154',1,'Torneig']]],
  ['llegir_5ftornejos_59',['llegir_tornejos',['../class_cjt__tornejos.html#a1353b909daa12fb1f542d028f1d79529',1,'Cjt_tornejos']]]
];
