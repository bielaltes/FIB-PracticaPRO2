var searchData=
[
  ['jugador_152',['Jugador',['../class_jugador.html#a0bac6ebd78bbdc5ed61be887a163ecc0',1,'Jugador']]]
];
