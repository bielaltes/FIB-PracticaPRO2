var searchData=
[
  ['cjt_5fcategories_105',['Cjt_categories',['../class_cjt__categories.html',1,'']]],
  ['cjt_5fjugadors_106',['Cjt_jugadors',['../class_cjt__jugadors.html',1,'']]],
  ['cjt_5ftornejos_107',['Cjt_tornejos',['../class_cjt__tornejos.html',1,'']]]
];
