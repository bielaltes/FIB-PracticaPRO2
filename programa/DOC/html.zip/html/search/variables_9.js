var searchData=
[
  ['p_199',['p',['../class_bin_tree.html#afe3647af1dda90f6ddf1deee6560fcf1',1,'BinTree']]],
  ['participants_200',['participants',['../class_torneig.html#a87196328ace3bbbae6f17f387835b3a6',1,'Torneig']]],
  ['partits_201',['partits',['../class_torneig.html#ac9844e83152867de56e418b1115c2d52',1,'Torneig']]],
  ['partits_5fguanyat_202',['partits_guanyat',['../class_jugador.html#a6bf9a674be86bfce7945f7c0dfbe531f',1,'Jugador']]],
  ['partits_5fperdut_203',['partits_perdut',['../class_jugador.html#ad1e6a56bea30a1449dbb37871c288fcf',1,'Jugador']]],
  ['pos_204',['pos',['../class_jugador.html#a25a7eeb0d334b2fe60bb490704c6626d',1,'Jugador']]],
  ['punts_205',['punts',['../class_torneig.html#a7b13a5ef959a87ee7de85f4f5b225c02',1,'Torneig']]],
  ['puntuacio_206',['puntuacio',['../class_cjt__categories.html#a121b331af19b7307f320b21f0edd8b30',1,'Cjt_categories']]]
];
