var searchData=
[
  ['actualitzar_5festadistiques_0',['actualitzar_estadistiques',['../class_cjt__jugadors.html#aa0e9faac43740de11fda44d07d97c60c',1,'Cjt_jugadors']]],
  ['actualitzar_5franking_1',['actualitzar_ranking',['../class_cjt__jugadors.html#ac4ce870bdd4c33796ca7ae81a0453407',1,'Cjt_jugadors']]],
  ['alcaraz_2',['Alcaraz',['../proves_8cc.html#aea2878a909755316e0279cb8d6d34d4d',1,'proves.cc']]],
  ['anteriors_5fparticipants_3',['anteriors_participants',['../class_torneig.html#a5ce5110cbb6fc8a30ec94bdeb5c837cb',1,'Torneig']]]
];
