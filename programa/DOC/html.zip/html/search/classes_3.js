var searchData=
[
  ['node_109',['Node',['../struct_bin_tree_1_1_node.html',1,'BinTree']]]
];
