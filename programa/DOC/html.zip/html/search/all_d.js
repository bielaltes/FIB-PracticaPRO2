var searchData=
[
  ['ramos_84',['Ramos',['../proves_8cc.html#a61b87a67934fef7341d457ca155473b1',1,'proves.cc']]],
  ['ranking_85',['ranking',['../class_cjt__jugadors.html#af9f7e71820fb657bf489ce72a31e8034',1,'Cjt_jugadors']]],
  ['restar_5fpunts_86',['restar_punts',['../class_torneig.html#ac8a8318fd1bc940649d12e300906c530',1,'Torneig']]],
  ['right_87',['right',['../struct_bin_tree_1_1_node.html#a6df770137090da60cd0376ce06893cbd',1,'BinTree::Node::right()'],['../class_bin_tree.html#aff8e96651b27284c329667b5ad3e4d0b',1,'BinTree::right()']]]
];
