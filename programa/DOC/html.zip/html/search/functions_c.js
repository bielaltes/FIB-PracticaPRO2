var searchData=
[
  ['torneig_171',['Torneig',['../class_torneig.html#a9794723939612dccda9f9a3979789b11',1,'Torneig']]]
];
