var searchData=
[
  ['torneig_91',['Torneig',['../class_torneig.html',1,'Torneig'],['../class_torneig.html#a9794723939612dccda9f9a3979789b11',1,'Torneig::Torneig()']]],
  ['torneig_2ecc_92',['Torneig.cc',['../_torneig_8cc.html',1,'']]],
  ['torneig_2ehh_93',['Torneig.hh',['../_torneig_8hh.html',1,'']]],
  ['tornejos_94',['tornejos',['../class_cjt__tornejos.html#a4b3d9bdd2ed133d76284fb510ebe9800',1,'Cjt_tornejos']]],
  ['tornejos_5fdisputat_95',['tornejos_disputat',['../class_jugador.html#a2ef0821abd64385a58561b039c37a469',1,'Jugador']]]
];
