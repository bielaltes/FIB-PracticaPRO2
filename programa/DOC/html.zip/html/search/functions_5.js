var searchData=
[
  ['imprimir_5fcategories_144',['imprimir_categories',['../class_cjt__categories.html#ad1a67d725173663782d1385ff59f0be6',1,'Cjt_categories']]],
  ['imprimir_5femparellaments_145',['imprimir_emparellaments',['../class_torneig.html#a17f4a939167e6ed018ee46580621abae',1,'Torneig']]],
  ['imprimir_5fjugadors_146',['imprimir_jugadors',['../class_cjt__jugadors.html#a9821d65fda187cb5983d98e4e86fc073',1,'Cjt_jugadors']]],
  ['imprimir_5fpunts_147',['imprimir_punts',['../class_torneig.html#a2e0eb7f4e3837fd969046f9f221b7fc6',1,'Torneig']]],
  ['imprimir_5franking_148',['imprimir_ranking',['../class_cjt__jugadors.html#a63581fdbdfaba9aeb5f0b3b466160902',1,'Cjt_jugadors']]],
  ['imprimir_5fresultats_149',['imprimir_resultats',['../class_torneig.html#a14dcde3f1ecc6e7c86a1c1dd925d029f',1,'Torneig']]],
  ['imprimir_5ftornejos_150',['imprimir_tornejos',['../class_cjt__tornejos.html#a52b8a773c1e137c268d847a9da81e891',1,'Cjt_tornejos']]],
  ['iniciar_5ftorneig_151',['iniciar_torneig',['../class_cjt__tornejos.html#ae8c099350f8903c61ca73fddfaeebffa',1,'Cjt_tornejos::iniciar_torneig()'],['../class_torneig.html#abcc9f0b1127a5fdd57856a59e5034e1f',1,'Torneig::iniciar_torneig()']]]
];
