var searchData=
[
  ['actualitzar_5festadistiques_124',['actualitzar_estadistiques',['../class_cjt__jugadors.html#aa0e9faac43740de11fda44d07d97c60c',1,'Cjt_jugadors']]],
  ['actualitzar_5franking_125',['actualitzar_ranking',['../class_cjt__jugadors.html#ac4ce870bdd4c33796ca7ae81a0453407',1,'Cjt_jugadors']]]
];
