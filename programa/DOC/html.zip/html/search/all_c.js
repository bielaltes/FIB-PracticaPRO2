var searchData=
[
  ['p_74',['p',['../class_bin_tree.html#afe3647af1dda90f6ddf1deee6560fcf1',1,'BinTree']]],
  ['participants_75',['participants',['../class_torneig.html#a87196328ace3bbbae6f17f387835b3a6',1,'Torneig']]],
  ['partits_76',['partits',['../class_torneig.html#ac9844e83152867de56e418b1115c2d52',1,'Torneig']]],
  ['partits_5fguanyat_77',['partits_guanyat',['../class_jugador.html#a6bf9a674be86bfce7945f7c0dfbe531f',1,'Jugador']]],
  ['partits_5fperdut_78',['partits_perdut',['../class_jugador.html#ad1e6a56bea30a1449dbb37871c288fcf',1,'Jugador']]],
  ['pos_79',['pos',['../class_jugador.html#a25a7eeb0d334b2fe60bb490704c6626d',1,'Jugador']]],
  ['program_2ecc_80',['program.cc',['../program_8cc.html',1,'']]],
  ['proves_2ecc_81',['proves.cc',['../proves_8cc.html',1,'']]],
  ['punts_82',['punts',['../class_torneig.html#a7b13a5ef959a87ee7de85f4f5b225c02',1,'Torneig']]],
  ['puntuacio_83',['puntuacio',['../class_cjt__categories.html#a121b331af19b7307f320b21f0edd8b30',1,'Cjt_categories']]]
];
