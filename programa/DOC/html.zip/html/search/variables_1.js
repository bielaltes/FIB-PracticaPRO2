var searchData=
[
  ['bautista_180',['Bautista',['../proves_8cc.html#a1907df21f4cdb306c58ea3f3aa7fe463',1,'proves.cc']]],
  ['berrettini_181',['Berrettini',['../proves_8cc.html#af89570e08079e02ecedd16da97fdafa9',1,'proves.cc']]]
];
