var searchData=
[
  ['node_64',['Node',['../struct_bin_tree_1_1_node.html',1,'BinTree&lt; T &gt;::Node'],['../struct_bin_tree_1_1_node.html#af45885e303875c018e89fa5c8b96bde0',1,'BinTree::Node::Node()']]],
  ['nom_65',['nom',['../class_jugador.html#afd6bec98df8ebb3d2db3ef583a76cfa1',1,'Jugador']]],
  ['nom_5fcategoria_66',['nom_categoria',['../class_cjt__categories.html#abf84a9eb9c89846b4746a8f0cc3afb2f',1,'Cjt_categories']]],
  ['nom_5fjugador_67',['nom_jugador',['../class_cjt__jugadors.html#afb644fcd07419fb30dc37db5a1663a73',1,'Cjt_jugadors']]],
  ['noms_68',['noms',['../class_cjt__categories.html#a45622c30fae365dc72f2d7aa5fbc3bfc',1,'Cjt_categories']]],
  ['nou_5fjugador_69',['nou_jugador',['../class_cjt__jugadors.html#ad59d2f11a4bbfd1053c0dba9062595af',1,'Cjt_jugadors']]],
  ['nou_5ftorneig_70',['nou_torneig',['../class_cjt__tornejos.html#a71e258c45895e7e97bdf201bec99f865',1,'Cjt_tornejos']]],
  ['num_5fcategories_71',['num_categories',['../class_cjt__categories.html#a78445bc84e521a95e7314ec4ac2565ad',1,'Cjt_categories']]],
  ['num_5fparticipants_72',['num_participants',['../class_torneig.html#aef9f0b6e93895593e4527cdd3e4e31ea',1,'Torneig']]],
  ['num_5ftornejos_73',['num_tornejos',['../class_cjt__tornejos.html#afe968dc02bf4f83842c53c5a76182f2f',1,'Cjt_tornejos']]]
];
