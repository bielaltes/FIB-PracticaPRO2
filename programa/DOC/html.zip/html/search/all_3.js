var searchData=
[
  ['delbonis_30',['Delbonis',['../proves_8cc.html#ad6cefd845df5cf8859a6c2e3260b0756',1,'proves.cc']]],
  ['dimitrov_31',['Dimitrov',['../proves_8cc.html#a599f891ef697ccaea03cfa50a30d4d89',1,'proves.cc']]]
];
