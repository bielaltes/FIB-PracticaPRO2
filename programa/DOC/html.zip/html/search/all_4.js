var searchData=
[
  ['eliminar_5fjugador_32',['eliminar_jugador',['../class_cjt__tornejos.html#acd74b9196cc0c9af8cc572e2112d0279',1,'Cjt_tornejos']]],
  ['eliminar_5fparticipant_33',['eliminar_participant',['../class_torneig.html#abb513cd4c98a86b799736b8118f94c5b',1,'Torneig']]],
  ['empty_34',['empty',['../class_bin_tree.html#a74cda259ba5c25b8ee38ed4dc33e4fad',1,'BinTree']]],
  ['escriure_5fjugador_35',['escriure_jugador',['../class_jugador.html#a2649293855d738934650cd8e26011df2',1,'Jugador']]]
];
