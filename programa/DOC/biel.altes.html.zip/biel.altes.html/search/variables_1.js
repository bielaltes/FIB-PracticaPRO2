var searchData=
[
  ['jocs_5fguanyat_131',['jocs_guanyat',['../class_jugador.html#a0eb97835e7dd3143f626c1d15edb7392',1,'Jugador']]],
  ['jocs_5fperdut_132',['jocs_perdut',['../class_jugador.html#a04e5cf90e57c490b4c088e29763479f7',1,'Jugador']]],
  ['jugadors_133',['jugadors',['../class_cjt__jugadors.html#a9a7fd899cca7f3c126120c8e7b4719d4',1,'Cjt_jugadors']]]
];
