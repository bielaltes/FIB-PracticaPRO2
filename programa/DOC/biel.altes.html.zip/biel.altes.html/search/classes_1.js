var searchData=
[
  ['jugador_75',['Jugador',['../class_jugador.html',1,'']]]
];
