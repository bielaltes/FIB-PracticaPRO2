var searchData=
[
  ['partits_5fguanyats_117',['partits_guanyats',['../class_jugador.html#a67437c27e06701ebd978c250c87ce82a',1,'Jugador']]],
  ['partits_5fperduts_118',['partits_perduts',['../class_jugador.html#a1d2d62be54fc5ed685c82cd4a4301fb1',1,'Jugador']]]
];
