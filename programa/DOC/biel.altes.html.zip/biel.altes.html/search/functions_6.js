var searchData=
[
  ['jocs_5fguanyats_103',['jocs_guanyats',['../class_jugador.html#af4fa2a8b680cd32e4578d8cad88e1170',1,'Jugador']]],
  ['jocs_5fperduts_104',['jocs_perduts',['../class_jugador.html#ab6a5f12c9015eb1b506041b8d3c05690',1,'Jugador']]],
  ['jugador_105',['Jugador',['../class_jugador.html#a232c46f75691af6210096e5972535d71',1,'Jugador']]]
];
