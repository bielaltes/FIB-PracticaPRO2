var searchData=
[
  ['participants_46',['participants',['../class_torneig.html#a6c844646cdb0ae0bc94bb7e4c7897012',1,'Torneig']]],
  ['partit_5fperdut_47',['partit_perdut',['../class_jugador.html#a9a2b733e6547913be707af6022dfbb61',1,'Jugador']]],
  ['partits_5fguanyat_48',['partits_guanyat',['../class_jugador.html#a6bf9a674be86bfce7945f7c0dfbe531f',1,'Jugador']]],
  ['partits_5fguanyats_49',['partits_guanyats',['../class_jugador.html#a67437c27e06701ebd978c250c87ce82a',1,'Jugador']]],
  ['partits_5fperduts_50',['partits_perduts',['../class_jugador.html#a1d2d62be54fc5ed685c82cd4a4301fb1',1,'Jugador']]],
  ['pos_51',['pos',['../class_jugador.html#a25a7eeb0d334b2fe60bb490704c6626d',1,'Jugador']]],
  ['program_2ecc_52',['program.cc',['../program_8cc.html',1,'']]],
  ['punts_53',['punts',['../class_categoria.html#a02abd0de204bc833ef030bcf0bc2bbd0',1,'Categoria::punts()'],['../class_jugador.html#a438340e55baaec15ec14e854d646a37a',1,'Jugador::punts()']]]
];
