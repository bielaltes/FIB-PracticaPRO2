var searchData=
[
  ['finalitzar_5ftorneig_20',['finalitzar_torneig',['../class_cjt__tornejos.html#ac12030fc4c0f063b54d62515f0b818b7',1,'Cjt_tornejos']]]
];
