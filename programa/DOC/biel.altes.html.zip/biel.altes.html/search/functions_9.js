var searchData=
[
  ['nou_5fjugador_113',['nou_jugador',['../class_cjt__jugadors.html#abc12f64a28c23ba5bd1e94814476de6e',1,'Cjt_jugadors']]],
  ['nou_5ftorneig_114',['nou_torneig',['../class_cjt__tornejos.html#ac4298fab4f5ed1d33c762dd837f50b8a',1,'Cjt_tornejos']]],
  ['num_5fcategories_115',['num_categories',['../class_cjt__categories.html#a78445bc84e521a95e7314ec4ac2565ad',1,'Cjt_categories']]],
  ['num_5fjugadors_116',['num_jugadors',['../class_cjt__jugadors.html#a14e8b610f807be05ddca76059ad4b762',1,'Cjt_jugadors']]]
];
