var searchData=
[
  ['torneig_121',['Torneig',['../class_torneig.html#a833b2f486a1648a8741d2115a9bb186c',1,'Torneig']]],
  ['tornejos_5fdisputats_122',['tornejos_disputats',['../class_jugador.html#a2b9ca8fd08627b1a206e2b1a329bc36b',1,'Jugador']]]
];
