var searchData=
[
  ['sets_5fguanyats_119',['sets_guanyats',['../class_jugador.html#a8b544dc5d87110a7eca88ec455ef8fc5',1,'Jugador']]],
  ['sets_5fperduts_120',['sets_perduts',['../class_jugador.html#a637f5c37a45af194c5c2fc95d2fdbec2',1,'Jugador']]]
];
