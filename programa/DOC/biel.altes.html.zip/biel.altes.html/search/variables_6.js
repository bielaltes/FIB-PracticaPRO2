var searchData=
[
  ['tornejos_144',['tornejos',['../class_cjt__tornejos.html#a7fdeb180ab77aed055850175e334f5d1',1,'Cjt_tornejos']]],
  ['tornejos_5fdisputat_145',['tornejos_disputat',['../class_jugador.html#a2ef0821abd64385a58561b039c37a469',1,'Jugador']]]
];
