var indexSectionsWithContent =
{
  0: "abcefijlmnprstv~",
  1: "cjt",
  2: "cjpt",
  3: "abcefijlmnpst~",
  4: "cjnprstv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Tot",
  1: "Classes",
  2: "Fitxers",
  3: "Funcions",
  4: "Variables"
};

