var searchData=
[
  ['sets_5fguanyat_55',['sets_guanyat',['../class_jugador.html#a396b226c722425d387f36e239fc9855c',1,'Jugador']]],
  ['sets_5fguanyats_56',['sets_guanyats',['../class_jugador.html#a8b544dc5d87110a7eca88ec455ef8fc5',1,'Jugador']]],
  ['sets_5fperdut_57',['sets_perdut',['../class_jugador.html#a7c9fcb3ec52c2c400e7cf8faaf945426',1,'Jugador']]],
  ['sets_5fperduts_58',['sets_perduts',['../class_jugador.html#a637f5c37a45af194c5c2fc95d2fdbec2',1,'Jugador']]]
];
