var searchData=
[
  ['jocs_5fguanyat_26',['jocs_guanyat',['../class_jugador.html#a0eb97835e7dd3143f626c1d15edb7392',1,'Jugador']]],
  ['jocs_5fguanyats_27',['jocs_guanyats',['../class_jugador.html#af4fa2a8b680cd32e4578d8cad88e1170',1,'Jugador']]],
  ['jocs_5fperdut_28',['jocs_perdut',['../class_jugador.html#a04e5cf90e57c490b4c088e29763479f7',1,'Jugador']]],
  ['jocs_5fperduts_29',['jocs_perduts',['../class_jugador.html#ab6a5f12c9015eb1b506041b8d3c05690',1,'Jugador']]],
  ['jugador_30',['Jugador',['../class_jugador.html',1,'Jugador'],['../class_jugador.html#a232c46f75691af6210096e5972535d71',1,'Jugador::Jugador()']]],
  ['jugador_2ehh_31',['jugador.hh',['../jugador_8hh.html',1,'']]],
  ['jugadors_32',['jugadors',['../class_cjt__jugadors.html#a9a7fd899cca7f3c126120c8e7b4719d4',1,'Cjt_jugadors']]]
];
