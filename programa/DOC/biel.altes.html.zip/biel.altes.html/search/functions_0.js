var searchData=
[
  ['actualitzar_5franking_84',['actualitzar_ranking',['../class_cjt__jugadors.html#a5e12a36a7049121aef6a5cb46e6528ad',1,'Cjt_jugadors']]]
];
