var searchData=
[
  ['imprimir_5fcategories_98',['imprimir_categories',['../class_cjt__categories.html#ad1a67d725173663782d1385ff59f0be6',1,'Cjt_categories']]],
  ['imprimir_5fjugadors_99',['imprimir_jugadors',['../class_cjt__jugadors.html#a9821d65fda187cb5983d98e4e86fc073',1,'Cjt_jugadors']]],
  ['imprimir_5franking_100',['imprimir_ranking',['../class_cjt__jugadors.html#a63581fdbdfaba9aeb5f0b3b466160902',1,'Cjt_jugadors']]],
  ['imprimir_5ftornejos_101',['imprimir_tornejos',['../class_cjt__tornejos.html#a0950e966b60873b9ff216b2f8ec0c60a',1,'Cjt_tornejos']]],
  ['iniciar_5ftorneig_102',['iniciar_torneig',['../class_cjt__tornejos.html#a2c25098715760c57d0eb2bd1acc02eae',1,'Cjt_tornejos']]]
];
