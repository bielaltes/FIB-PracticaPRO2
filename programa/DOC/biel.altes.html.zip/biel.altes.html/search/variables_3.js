var searchData=
[
  ['participants_136',['participants',['../class_torneig.html#a6c844646cdb0ae0bc94bb7e4c7897012',1,'Torneig']]],
  ['partit_5fperdut_137',['partit_perdut',['../class_jugador.html#a9a2b733e6547913be707af6022dfbb61',1,'Jugador']]],
  ['partits_5fguanyat_138',['partits_guanyat',['../class_jugador.html#a6bf9a674be86bfce7945f7c0dfbe531f',1,'Jugador']]],
  ['pos_139',['pos',['../class_jugador.html#a25a7eeb0d334b2fe60bb490704c6626d',1,'Jugador']]],
  ['punts_140',['punts',['../class_categoria.html#a02abd0de204bc833ef030bcf0bc2bbd0',1,'Categoria::punts()'],['../class_jugador.html#a438340e55baaec15ec14e854d646a37a',1,'Jugador::punts()']]]
];
