var searchData=
[
  ['torneig_2ehh_83',['torneig.hh',['../torneig_8hh.html',1,'']]]
];
