var searchData=
[
  ['ranking_54',['ranking',['../class_cjt__jugadors.html#abf1ad90af76e852f6267f637a4fda894',1,'Cjt_jugadors']]]
];
