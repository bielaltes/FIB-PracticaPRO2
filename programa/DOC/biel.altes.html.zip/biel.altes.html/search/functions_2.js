var searchData=
[
  ['categoria_87',['Categoria',['../class_categoria.html#a63cf18c90034d9fba9ec79088f33f47d',1,'Categoria']]],
  ['cjt_5fcategories_88',['Cjt_categories',['../class_cjt__categories.html#aff8ea1aca086241e8a10bc4814e86ec0',1,'Cjt_categories']]],
  ['cjt_5fjugadors_89',['Cjt_jugadors',['../class_cjt__jugadors.html#a473281833edd8838e3517fff07a6b9f1',1,'Cjt_jugadors']]],
  ['cjt_5ftornejos_90',['Cjt_tornejos',['../class_cjt__tornejos.html#a802f937a72b37c2a675734cb3d6f6257',1,'Cjt_tornejos']]],
  ['consultar_5fcategoria_91',['consultar_categoria',['../class_torneig.html#a78a82b011e01b5d07ade6378da916c3c',1,'Torneig']]],
  ['consultar_5fjugador_92',['consultar_jugador',['../class_cjt__jugadors.html#a2232be18d9336daa80680ee29a5e9f28',1,'Cjt_jugadors']]],
  ['consultar_5fnom_93',['consultar_nom',['../class_categoria.html#a99e68d77bab3b652aee54ba09e302238',1,'Categoria::consultar_nom()'],['../class_jugador.html#a44796353316adc3821484969c75f9457',1,'Jugador::consultar_nom()'],['../class_torneig.html#a1a7fbad38abbfd0bb42b0116ffa67524',1,'Torneig::consultar_nom()']]],
  ['consultar_5fpunts_94',['consultar_punts',['../class_categoria.html#a67d5c6d5efb82b9b173079bb01f0ca24',1,'Categoria']]]
];
