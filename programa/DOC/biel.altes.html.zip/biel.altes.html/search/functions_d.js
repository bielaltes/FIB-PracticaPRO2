var searchData=
[
  ['_7ecategoria_123',['~Categoria',['../class_categoria.html#a2fa3d74dfe8be2db3838980de35e0eb6',1,'Categoria']]],
  ['_7ecjt_5fcategories_124',['~Cjt_categories',['../class_cjt__categories.html#a768f340b8389161d8dc565ecf8853f4f',1,'Cjt_categories']]],
  ['_7ecjt_5fjugadors_125',['~Cjt_jugadors',['../class_cjt__jugadors.html#a49d29aca09d1060d8c3db9771125b85f',1,'Cjt_jugadors']]],
  ['_7ecjt_5ftornejos_126',['~Cjt_tornejos',['../class_cjt__tornejos.html#a0c3c68b4cc7c962a2b8d6f9efeb2a84e',1,'Cjt_tornejos']]],
  ['_7ejugador_127',['~Jugador',['../class_jugador.html#a9db1d422fe3b675f92d9fd687b1f42c4',1,'Jugador']]],
  ['_7etorneig_128',['~Torneig',['../class_torneig.html#ab5184085575669dd522e11a25f602943',1,'Torneig']]]
];
