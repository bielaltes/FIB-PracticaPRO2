var searchData=
[
  ['torneig_59',['Torneig',['../class_torneig.html',1,'Torneig'],['../class_torneig.html#a833b2f486a1648a8741d2115a9bb186c',1,'Torneig::Torneig()']]],
  ['torneig_2ehh_60',['torneig.hh',['../torneig_8hh.html',1,'']]],
  ['tornejos_61',['tornejos',['../class_cjt__tornejos.html#a7fdeb180ab77aed055850175e334f5d1',1,'Cjt_tornejos']]],
  ['tornejos_5fdisputat_62',['tornejos_disputat',['../class_jugador.html#a2ef0821abd64385a58561b039c37a469',1,'Jugador']]],
  ['tornejos_5fdisputats_63',['tornejos_disputats',['../class_jugador.html#a2b9ca8fd08627b1a206e2b1a329bc36b',1,'Jugador']]]
];
