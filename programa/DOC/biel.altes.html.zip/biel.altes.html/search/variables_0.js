var searchData=
[
  ['c_129',['C',['../class_cjt__categories.html#a1d3d6eb2bd5a981ca1e56d4d16e7d1c1',1,'Cjt_categories']]],
  ['categoria_130',['categoria',['../class_torneig.html#a8a80ab41ebab7d88a2569247c6ec4c81',1,'Torneig']]]
];
