var searchData=
[
  ['nom_134',['nom',['../class_categoria.html#ad39955d54081f0d7f31db96909a4f6bf',1,'Categoria::nom()'],['../class_jugador.html#afd6bec98df8ebb3d2db3ef583a76cfa1',1,'Jugador::nom()'],['../class_torneig.html#a803fb4b7e0637c93229eb562a280c681',1,'Torneig::nom()']]],
  ['num_5ftornejos_135',['num_tornejos',['../class_cjt__tornejos.html#afe968dc02bf4f83842c53c5a76182f2f',1,'Cjt_tornejos']]]
];
