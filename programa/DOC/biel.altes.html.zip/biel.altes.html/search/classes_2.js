var searchData=
[
  ['torneig_76',['Torneig',['../class_torneig.html',1,'']]]
];
