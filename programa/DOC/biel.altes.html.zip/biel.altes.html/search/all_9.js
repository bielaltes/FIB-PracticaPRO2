var searchData=
[
  ['nom_40',['nom',['../class_categoria.html#ad39955d54081f0d7f31db96909a4f6bf',1,'Categoria::nom()'],['../class_jugador.html#afd6bec98df8ebb3d2db3ef583a76cfa1',1,'Jugador::nom()'],['../class_torneig.html#a803fb4b7e0637c93229eb562a280c681',1,'Torneig::nom()']]],
  ['nou_5fjugador_41',['nou_jugador',['../class_cjt__jugadors.html#abc12f64a28c23ba5bd1e94814476de6e',1,'Cjt_jugadors']]],
  ['nou_5ftorneig_42',['nou_torneig',['../class_cjt__tornejos.html#ac4298fab4f5ed1d33c762dd837f50b8a',1,'Cjt_tornejos']]],
  ['num_5fcategories_43',['num_categories',['../class_cjt__categories.html#a78445bc84e521a95e7314ec4ac2565ad',1,'Cjt_categories']]],
  ['num_5fjugadors_44',['num_jugadors',['../class_cjt__jugadors.html#a14e8b610f807be05ddca76059ad4b762',1,'Cjt_jugadors']]],
  ['num_5ftornejos_45',['num_tornejos',['../class_cjt__tornejos.html#afe968dc02bf4f83842c53c5a76182f2f',1,'Cjt_tornejos']]]
];
