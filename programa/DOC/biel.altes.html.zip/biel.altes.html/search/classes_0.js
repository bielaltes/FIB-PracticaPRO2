var searchData=
[
  ['categoria_71',['Categoria',['../class_categoria.html',1,'']]],
  ['cjt_5fcategories_72',['Cjt_categories',['../class_cjt__categories.html',1,'']]],
  ['cjt_5fjugadors_73',['Cjt_jugadors',['../class_cjt__jugadors.html',1,'']]],
  ['cjt_5ftornejos_74',['Cjt_tornejos',['../class_cjt__tornejos.html',1,'']]]
];
