var searchData=
[
  ['baixa_5fjugador_1',['baixa_jugador',['../class_cjt__jugadors.html#a902057929aebe8b46ff16395ad22def2',1,'Cjt_jugadors']]],
  ['baixa_5ftorneig_2',['baixa_torneig',['../class_cjt__tornejos.html#ae549ea64527b0876bb395ba957faf387',1,'Cjt_tornejos']]]
];
