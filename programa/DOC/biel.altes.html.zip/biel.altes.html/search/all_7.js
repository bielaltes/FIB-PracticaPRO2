var searchData=
[
  ['llegeix_5fcategoria_33',['llegeix_categoria',['../class_categoria.html#afcc187c0f598d99f85873ef3fc60013f',1,'Categoria']]],
  ['llegeix_5fjugador_34',['llegeix_jugador',['../class_jugador.html#abbe2beb1eb668c9628295bac19c178a8',1,'Jugador']]],
  ['llegeix_5ftorneig_35',['llegeix_torneig',['../class_torneig.html#a7c98401eb91e41fad91cd487ad1b7f65',1,'Torneig']]],
  ['llegir_5fcategories_36',['llegir_categories',['../class_cjt__categories.html#aec7c99f38b0e4a59e804b5bf9ed1a4c8',1,'Cjt_categories']]],
  ['llegir_5fjugadors_37',['llegir_jugadors',['../class_cjt__jugadors.html#affe03f05c962b8689540de5e1aa97d0a',1,'Cjt_jugadors']]],
  ['llegir_5ftornejos_38',['llegir_tornejos',['../class_cjt__tornejos.html#acc9a50af4b8896eb4e3faebb495a2ac7',1,'Cjt_tornejos']]]
];
