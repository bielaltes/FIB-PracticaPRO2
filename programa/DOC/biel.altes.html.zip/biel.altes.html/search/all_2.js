var searchData=
[
  ['c_3',['C',['../class_cjt__categories.html#a1d3d6eb2bd5a981ca1e56d4d16e7d1c1',1,'Cjt_categories']]],
  ['categoria_4',['Categoria',['../class_categoria.html',1,'']]],
  ['categoria_5',['categoria',['../class_torneig.html#a8a80ab41ebab7d88a2569247c6ec4c81',1,'Torneig']]],
  ['categoria_6',['Categoria',['../class_categoria.html#a63cf18c90034d9fba9ec79088f33f47d',1,'Categoria']]],
  ['categoria_2ehh_7',['categoria.hh',['../categoria_8hh.html',1,'']]],
  ['cjt_5fcategories_8',['Cjt_categories',['../class_cjt__categories.html',1,'Cjt_categories'],['../class_cjt__categories.html#aff8ea1aca086241e8a10bc4814e86ec0',1,'Cjt_categories::Cjt_categories()']]],
  ['cjt_5fcategories_2ehh_9',['Cjt_categories.hh',['../_cjt__categories_8hh.html',1,'']]],
  ['cjt_5fjugadors_10',['Cjt_jugadors',['../class_cjt__jugadors.html',1,'Cjt_jugadors'],['../class_cjt__jugadors.html#a473281833edd8838e3517fff07a6b9f1',1,'Cjt_jugadors::Cjt_jugadors()']]],
  ['cjt_5fjugadors_2ehh_11',['Cjt_jugadors.hh',['../_cjt__jugadors_8hh.html',1,'']]],
  ['cjt_5ftornejos_12',['Cjt_tornejos',['../class_cjt__tornejos.html',1,'Cjt_tornejos'],['../class_cjt__tornejos.html#a802f937a72b37c2a675734cb3d6f6257',1,'Cjt_tornejos::Cjt_tornejos()']]],
  ['cjt_5ftornejos_2ehh_13',['Cjt_tornejos.hh',['../_cjt__tornejos_8hh.html',1,'']]],
  ['consultar_5fcategoria_14',['consultar_categoria',['../class_torneig.html#a78a82b011e01b5d07ade6378da916c3c',1,'Torneig']]],
  ['consultar_5fjugador_15',['consultar_jugador',['../class_cjt__jugadors.html#a2232be18d9336daa80680ee29a5e9f28',1,'Cjt_jugadors']]],
  ['consultar_5fnom_16',['consultar_nom',['../class_categoria.html#a99e68d77bab3b652aee54ba09e302238',1,'Categoria::consultar_nom()'],['../class_jugador.html#a44796353316adc3821484969c75f9457',1,'Jugador::consultar_nom()'],['../class_torneig.html#a1a7fbad38abbfd0bb42b0116ffa67524',1,'Torneig::consultar_nom()']]],
  ['consultar_5fpunts_17',['consultar_punts',['../class_categoria.html#a67d5c6d5efb82b9b173079bb01f0ca24',1,'Categoria']]]
];
