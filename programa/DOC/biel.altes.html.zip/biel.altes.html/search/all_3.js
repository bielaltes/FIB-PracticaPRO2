var searchData=
[
  ['escriu_5fcategoria_18',['escriu_categoria',['../class_categoria.html#ace72584479577989887645222ca5f540',1,'Categoria']]],
  ['escriure_5fjugador_19',['escriure_jugador',['../class_jugador.html#a3a810cc4df70e88b8dc368d846bd75eb',1,'Jugador']]]
];
